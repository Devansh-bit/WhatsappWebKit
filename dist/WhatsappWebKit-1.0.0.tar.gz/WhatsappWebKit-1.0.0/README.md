# Welcome to WhatsappWebKit

### *pip install WhatsappWebKit*

This library is the gateway for automation of whatsapp web (especially for students :))

Just by writing few lines of code, you can process messages, reply to chats, message someone
automatically (There is also the GoogleMeet module which can help you join classes and leave
them after certain time automatically!)!  This library is based on selenium webdriver and requires 
that you have Chrome installed and the supported version of chromedriver. Visit the github
page (https://github.com/Devansh-bit/WhatsappWebKit) for demo programs
(tests dir) {coming soon!}. Please contribute to the project, even an update to this README
 will be appreciated!

(I am 16 and still learning in the world of open source! Your support is greatly appreciated!)