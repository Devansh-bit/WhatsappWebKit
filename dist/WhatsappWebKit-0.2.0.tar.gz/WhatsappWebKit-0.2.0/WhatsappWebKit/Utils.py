from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from WhatsappWebKit import Locators
from selenium import webdriver
class Utils:
    def __init__(self, driver:webdriver.Chrome):
        self.driver = driver

    def get_text_from_message(self, message):
        """Converts message/list of message object(s) to text
           Returns message_deleted if the message was deleted or did not contain text"""

        if type(message) == WebElement:
            try:
                return message.find_element(By.XPATH,
                                            ".//span[@class='_1VzZY selectable-text invisible-space copyable-text']/span").text
            except NoSuchElementException:
                return "message_deleted"
        elif type(message) == list:
            msg_list = []
            for msg in message:
                try:
                    msg_list.append(msg.find_element(By.XPATH,
                                                     ".//span[@class='_1VzZY selectable-text invisible-space copyable-text']/span").text)
                except NoSuchElementException:
                    msg_list.append("message_deleted")
            return msg_list
        else:
            return None