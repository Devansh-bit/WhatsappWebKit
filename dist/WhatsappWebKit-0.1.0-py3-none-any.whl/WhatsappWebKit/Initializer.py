from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from WhatsappWebKit import Locators, Utils

def create_driver(path_to_chromedriver):
    driver = webdriver.Chrome(path_to_chromedriver)
    return driver
class WebDriver(Locators.window, Utils.Utils):
    def __init__(self, driver):
        self.driver = driver
        self.driver.get("https://web.whatsapp.com")
        WebDriverWait(self.driver, 90).until(EC.visibility_of_element_located((By.XPATH, """//*[@id="side"]/div[1]/div/label/div/div[2]""")))
        super(WebDriver, self).__init__(self.driver)


